<?php
$name="3561756_sktravels";
$pass="Saikumar@7875";
$server="fdb29.awardspace.net";
$database="3561756_sktravels";
$con=mysqli_connect($server,$name,$pass,$database);

?>